package com.capgemini.salesmanagement.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.dao.IPoductDao;
import com.capgemini.salesmanagement.dao.ProductDao;
import com.capgemini.salesmanagement.exception.ProductException;

public class ProductService implements IProductService{

	IPoductDao dao=null;
	@Override
	public ProductBean getProductDetails(int productCode) throws ProductException, SQLException, IOException {
		dao= new ProductDao();
		
		ProductBean productBean=dao.getProductDetails(productCode);
		return productBean;
		
	}

	@Override
	public boolean insertSalesDetails(ProductBean productBean) throws ProductException, IOException {
		//System.out.println("service");
		dao=new ProductDao();
		return dao.insertSalesDetails(productBean);
		
	}

	public boolean validateProductCode(int product_code)
	{
		Pattern pattern=Pattern.compile("[1][0-9]{3}");
		Matcher matcher=pattern.matcher(String.valueOf(product_code));
		//System.out.println( matcher.matches());
		return matcher.matches();
	}
	public boolean validateQuantity(int quantity)
	{
		return quantity>0;
	}
	
}
